
import './App.css';
import Login from './components/login';
import "bootstrap/dist/css/bootstrap.css"
import { ApolloProvider } from "@apollo/client";
import {client} from "./clien"

function App() {
  return (
    <ApolloProvider client={client}>
      <div className="App">
        <Login />
      </div>
    </ApolloProvider>
  );
}

export default App;
