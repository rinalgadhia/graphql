import { ApolloClient, InMemoryCache } from "@apollo/client";
import { setContext } from 'apollo-link-context'
import {AUTH_TOKEN} from "./constants"

const authLink = setContext((_, { headers }) => {
  const token = localStorage.getItem(AUTH_TOKEN);
  return {
    headers: {
      ...headers,
      authorization: token ? `Bearer ${token}` : "",
    },
  };
});

export const client = new ApolloClient({
  link: authLink.concat(),
  cache: new InMemoryCache(),
});
